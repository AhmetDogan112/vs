﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Boy_kilo_endeksi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float boy;
            float kilo;
            boy=Convert.ToSingle(textBox2.Text);
            kilo = Convert.ToSingle(textBox1.Text);
            
                float boyMetre=boy;
                float vki=kilo/(boyMetre*boyMetre);
                string kategori;
                if (vki < 18.5)
                {
                    kategori = "zayıf";
                }
                else if (18.5 <= vki && vki < 25)
                {
                    kategori = "normal kilolu";
                }
                else if (25 <= vki && vki < 30)
                {
                    kategori = "fazla kilolu";
                }
                else
                {
                    kategori = "obez";
                }
                MessageBox.Show(kategori);

            }
            
            
             

            
        }
    }

